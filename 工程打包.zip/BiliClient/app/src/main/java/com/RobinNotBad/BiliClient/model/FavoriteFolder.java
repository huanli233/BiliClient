package com.RobinNotBad.BiliClient.model;

public class FavoriteFolder {
    private final long id;
    private final String name;
    private final String cover;
    private final int videoCount;
    private final int maxCount;

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getVideoCount() {
        return videoCount;
    }

    public String getCover() {
        return cover;
    }

    public int getMaxCount() {
        return maxCount;
    }

    public FavoriteFolder(long id, String name, String cover, int videoCount, int maxCount) {
        this.id = id;
        this.name = name;
        this.cover = cover;
        this.videoCount = videoCount;
        this.maxCount = maxCount;
    }
}
