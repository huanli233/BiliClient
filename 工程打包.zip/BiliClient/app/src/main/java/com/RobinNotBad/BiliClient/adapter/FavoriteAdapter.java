package com.RobinNotBad.BiliClient.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.user.FavoriteFolderActivity;
import com.RobinNotBad.BiliClient.listener.OnItemClickListener;
import com.RobinNotBad.BiliClient.model.FavoriteFolder;
import com.RobinNotBad.BiliClient.util.LittleToolsUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

//收藏夹Adapter

public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.FavoriteHolder> {

    Context context;
    ArrayList<FavoriteFolder> folderList;
    long mid;
    OnItemClickListener mClickListener;

    public void setOnClickJumpListener(){
        setOnItemClickListener(position -> {
            Intent intent = new Intent();
            intent.setClass(context, FavoriteFolderActivity.class);
            intent.putExtra("fid",folderList.get(position).getId());
            intent.putExtra("mid",mid);
            intent.putExtra("name",folderList.get(position).getName());
            context.startActivity(intent);
        });
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        this.mClickListener = listener;
    }

    public FavoriteAdapter(Context context, ArrayList<FavoriteFolder> folderList, long mid) {
        this.context = context;
        this.folderList = folderList;
        this.mid = mid;
    }

    @NonNull
    @Override
    public FavoriteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(this.context).inflate(R.layout.cell_favorite_folder_list,parent,false);
        return new FavoriteHolder(view,mClickListener);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull FavoriteHolder holder, int position) {
        holder.name.setText(LittleToolsUtil.htmlToString(folderList.get(position).getName()));
        holder.count.setText(folderList.get(position).getVideoCount() + "/" + folderList.get(position).getMaxCount());
        Glide.with(this.context).load(folderList.get(position).getCover())
                .apply(RequestOptions.bitmapTransform(new RoundedCorners(LittleToolsUtil.dp2px(5,context))))
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(holder.cover);
    }

    @Override
    public int getItemCount() {
        return folderList.size();
    }

    public static class FavoriteHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView name,count;
        ImageView cover;
        OnItemClickListener mListener;

        public FavoriteHolder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);
            mListener = listener;
            name = itemView.findViewById(R.id.title);
            count = itemView.findViewById(R.id.itemCount);
            cover = itemView.findViewById(R.id.cover);
            itemView.setOnClickListener(this);
        }
        @Override
        public void onClick(View v){
            if(mListener!=null) mListener.onItemClick(getAdapterPosition());
        }
    }
}
