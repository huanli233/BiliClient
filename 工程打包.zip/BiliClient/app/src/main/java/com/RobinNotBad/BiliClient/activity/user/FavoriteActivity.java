package com.RobinNotBad.BiliClient.activity.user;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.RobinNotBad.BiliClient.adapter.FavoriteAdapter;
import com.RobinNotBad.BiliClient.api.FavoriteApi;
import com.RobinNotBad.BiliClient.model.FavoriteFolder;
import com.RobinNotBad.BiliClient.util.ErrorUtil;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

//收藏夹列表
//2023-08-07

public class FavoriteActivity extends BaseActivity {

    private long mid;
    private RecyclerView recyclerView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        Intent intent = getIntent();
        mid = intent.getLongExtra("mid",0);

        findViewById(R.id.top).setOnClickListener(view -> finish());
        recyclerView = findViewById(R.id.recyclerView);

        new Thread(()->{
            try {
                ArrayList<FavoriteFolder> folderList = FavoriteApi.getFavoriteFolders(mid);
                FavoriteAdapter adapter = new FavoriteAdapter(this,folderList,mid);
                runOnUiThread(()->{
                    adapter.setOnClickJumpListener();
                    recyclerView.setLayoutManager(new LinearLayoutManager(this));
                    recyclerView.setAdapter(adapter);
                });
            } catch (IOException e) {
                runOnUiThread(()-> ErrorUtil.quickErr(ErrorUtil.err_net,this));
                e.printStackTrace();
            } catch (JSONException e) {
                runOnUiThread(()-> ErrorUtil.quickErr(ErrorUtil.err_json,this));
                e.printStackTrace();
            }
        }).start();
    }
}