package com.RobinNotBad.BiliClient.activity.video;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;

import java.util.ArrayList;

//分页视频选集，图省事就直接用ListView了，反正没有图片
//2023-07-17

public class MultiPageActivity extends BaseActivity {

    private ArrayList<Integer> cids;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi_page);
        ListView listView = findViewById(R.id.pages);
        findViewById(R.id.top).setOnClickListener(view -> finish());

        Intent intent = getIntent();
        cids = intent.getIntegerArrayListExtra("cids");
        ArrayList<String> pages = intent.getStringArrayListExtra("pages");
        String bvid = intent.getStringExtra("bvid");
        long aid = intent.getLongExtra("aid", 0);
        long mid = intent.getLongExtra("mid",0);


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.cell_text_simple, pages);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((adapterView, view, position, id) -> new Thread(()->{
            Intent intent1 = new Intent();
            intent1.setClassName("com.xinxiangshicheng.wearbiliplayer.cn", "com.xinxiangshicheng.wearbiliplayer.cn.ReceiveActivity");
            intent1.setAction(Intent.ACTION_VIEW);
            Log.e("cookie",SharedPreferencesUtil.getString("cookies",""));
            intent.putExtra("cookie", SharedPreferencesUtil.getString("cookies",""));
            intent1.setData(Uri.parse("wearbiliplayer://receive:8080/play?&bvid=" + bvid + "&cid=" + cids.get(position) + "&aid=" + aid));
            startActivity(intent1);
        }).start());
    }

}