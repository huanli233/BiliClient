package com.RobinNotBad.BiliClient.api;

import android.util.Log;

import com.RobinNotBad.BiliClient.model.VideoReply;
import com.RobinNotBad.BiliClient.util.LittleToolsUtil;
import com.RobinNotBad.BiliClient.util.NetWorkUtil;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

//腕上哔哩那边注释里写了一连串的麻烦麻烦麻烦，顿时预感不妙
//其实还好
//用Log直接替代注释了，应该都能看懂吧
//2023-07-22

public class ReplyApi {

    public static int getReplies(long oid, long rpid, int pn, ArrayList<VideoReply> replyArrayList) throws JSONException, IOException {
        String sort = rpid == 0 ? "2" : "0";

        String url = "http://api.bilibili.com/x/v2/reply" + (rpid == 0 ? "" : "/reply") + "?pn=" + pn
                + "&type=1&oid=" + oid + "&sort=" + sort + (rpid == 0 ? "" : ("&root=" + rpid));

        Log.e("debug-评论区链接", url);

        JSONObject all = new JSONObject(Objects.requireNonNull(NetWorkUtil.get(url, ConfInfoApi.defHeaders).body()).string());

        int size = replyArrayList.size();
        if (all.getInt("code") == 0 && !all.isNull("data")) {
            JSONObject data = all.getJSONObject("data");
            JSONObject page = data.getJSONObject("page");
            if (!data.isNull("replies") && page.getInt("size") > 0) {
                if (rpid == 0 && data.has("top_replies") && page.getInt("num") == 1)
                    analizeReplyArray(true, data.getJSONArray("top_replies"), replyArrayList);
                JSONArray replies = data.getJSONArray("replies");
                analizeReplyArray(rpid == 0, replies, replyArrayList);
                if(replyArrayList.size() == size)return 1;
                else return 0;
            } else return -1;
        } else return -1;
    }  //-1错误,0正常，1到底了

    public static void analizeReplyArray(boolean isRoot, JSONArray replies,ArrayList<VideoReply> replyArrayList) throws JSONException {
        for (int i = 0; i < replies.length(); i++) {
            Log.e("debug-第" + i + "条评论", "--------");
            JSONObject reply = replies.getJSONObject(i);
            long rpid = reply.getLong("rpid");    //这玩意不能用int，太长了数值溢出！！！有被坑到！！！
            Log.e("debug-评论id", String.valueOf(rpid));
            JSONObject member = reply.getJSONObject("member");
            String uname = member.getString("uname");
            long mid = member.getLong("mid");
            String avatar = member.getString("avatar");
            Log.e("debug-发送者", uname);
            Log.e("debug-发送者id", String.valueOf(mid));
            Log.e("debug-发送者头像", avatar);
            JSONObject content = reply.getJSONObject("content");
            String message = LittleToolsUtil.htmlToString(content.getString("message"));

            Log.e("debug-评论内容", message);
            int likeCount = reply.getInt("like");
            Log.e("debug-点赞数", String.valueOf(likeCount));
            boolean action = reply.getInt("action") == 1;

            JSONObject emote;
            if(content.has("emote") && !content.isNull("emote")) emote = content.getJSONObject("emote");
            else emote = null;
            //表情包列表 不知道咋办就直接传json了  显示部分见EmoteUtil

            JSONObject upAction = reply.getJSONObject("up_action");
            boolean upLiked = upAction.getBoolean("like");
            boolean upReplied = upAction.getBoolean("reply");
            //up主觉得很淦

            JSONObject replyCtrl = reply.getJSONObject("reply_control");
            String ctime;
            if(replyCtrl.has("location")) ctime = replyCtrl.getString("time_desc") + "  " + replyCtrl.getString("location");
            else ctime = replyCtrl.getString("time_desc");
            if(replyCtrl.has("is_up_top")){
                if(replyCtrl.getBoolean("is_up_top")) message = "[置顶]" + message;
            }
            Log.e("debug-时间和IP",ctime);

            if (isRoot) {
                ArrayList<String> pictureList = new ArrayList<>();
                ArrayList<String> childUNameList = new ArrayList<>();
                ArrayList<String> childMsgList = new ArrayList<>();

                if (content.has("pictures") && !content.isNull("pictures")) {
                    JSONArray pictures = content.getJSONArray("pictures");
                    for (int j = 0; j < pictures.length(); j++) {
                        JSONObject picture = pictures.getJSONObject(j);
                        Log.e("debug-第" + j + "张图片", picture.getString("img_src"));
                        pictureList.add(picture.getString("img_src"));
                    }
                }
                int rcount = reply.getInt("rcount");
                Log.e("debug-子评论数", String.valueOf(rcount));  //懒，数据有，但没有做显示。要是看到了帮我加上呗（
                if (reply.has("replies") && !reply.isNull("replies")) {  //这玩意还能返回空值？！气死人，信不信我把你彻底删了
                    JSONArray childReplies = reply.getJSONArray("replies");
                    for (int j = 0; j < childReplies.length(); j++) {
                        JSONObject childReply = childReplies.getJSONObject(j);
                        String childUName = childReply.getJSONObject("member").getString("uname");
                        String childMessage = childReply.getJSONObject("content").getString("message");
                        Log.e("debug-第" + j + "条子评论", childUName + "：" + childMessage);
                        childUNameList.add(childUName);
                        childMsgList.add(childMessage);
                    }
                }
                replyArrayList.add(new VideoReply(rpid,ctime, mid, uname, avatar, message,emote, pictureList,likeCount,upLiked,upReplied,action, rcount, childUNameList, childMsgList));
            }
            else replyArrayList.add(new VideoReply(rpid,ctime,mid,uname,avatar,message,emote,likeCount,upLiked,action));
        }
    }


    public boolean sendReply(long oid, long root, String type, String text) throws IOException, JSONException {
        String url = "https://api.bilibili.com/x/v2/reply/add";
        String arg = "oid=" + oid + "&type=" + type
                + (root == 0 ? "" : ("&root=" + root + "&parent=" + root))
                + "&message=" + text + "&jsonp=jsonp&csrf=" + SharedPreferencesUtil.getString("csrf","");
        JSONObject result = new JSONObject(Objects.requireNonNull(NetWorkUtil.post(url, arg, ConfInfoApi.defHeaders).body()).string());
        return result.getInt("code") == 0;
    }

    public boolean likeReply(long oid, long root, String type,  boolean action) throws IOException, JSONException {
        String url = "https://api.bilibili.com/x/v2/reply/action";
        String arg = "oid=" + oid + "&type=" + type + "&rpid=" + root + "&action=" + (action ? "1" : "0") + "&jsonp=jsonp&csrf=" + SharedPreferencesUtil.getString("csrf","");
        Log.e("debug-点赞链接",url + "?" + arg);
        JSONObject result = new JSONObject(Objects.requireNonNull(NetWorkUtil.post(url, arg, ConfInfoApi.defHeaders).body()).string());
        return result.getInt("code") == 0;
    }
}
