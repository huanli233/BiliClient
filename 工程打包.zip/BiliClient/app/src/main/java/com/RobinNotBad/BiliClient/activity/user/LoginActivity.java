package com.RobinNotBad.BiliClient.activity.user;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.RobinNotBad.BiliClient.activity.SplashActivity;
import com.RobinNotBad.BiliClient.api.UserLoginApi;
import com.RobinNotBad.BiliClient.util.ErrorUtil;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;

import org.json.JSONObject;

import java.io.IOException;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.Response;

//登录页面，参考了腕上哔哩和WearBili的代码

public class LoginActivity extends BaseActivity {
    private int timeoutCount;
    private ImageView qrImageView;
    private TextView scanStat;
    Bitmap QRImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Log.e("debug","进入登录页面");

        findViewById(R.id.top).setOnClickListener(view -> finish());

        qrImageView = findViewById(R.id.qrImage);
        scanStat = findViewById(R.id.scanStat);

        qrImageView.setOnClickListener(view -> {
            try {
                refreshQrCode();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });


        try {
            refreshQrCode();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void refreshQrCode() throws IOException {
        qrImageView.setEnabled(false);
        qrImageView.setImageResource(R.drawable.loading);
        new Thread(() ->{
            try{
                runOnUiThread(() -> scanStat.setText("正在获取二维码"));
                QRImage = UserLoginApi.getLoginQR();
                runOnUiThread(() -> {
                    scanStat.setText("请使用手机客户端扫码登录");
                    qrImageView.setImageBitmap(QRImage);
                    detectLogin();
                });
            } catch (Exception e) {
                qrImageView.setEnabled(true);
                runOnUiThread(() -> scanStat.setText("获取二维码失败，点击上方重试"));
                e.printStackTrace();
            }
        }).start();
    }

    public void detectLogin(){
        timeoutCount = 0;
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                try {
                    Response response = UserLoginApi.getLoginState();
                    assert response.body() != null;
                    JSONObject loginJson = new JSONObject(response.body().string());
                    if (!(Boolean) loginJson.get("status")) {
                        if((int) loginJson.get("data") == -5) runOnUiThread(() -> scanStat.setText("已扫描，请在手机上点击登录"));
                    }
                    else {
                        StringBuilder cookies = new StringBuilder();
                        List<String> cookiesList = response.headers("Set-Cookie");
                        for (int i = 0; i < cookiesList.size(); i++)
                            cookies.append(cookiesList.get(i).split("; ")[0]).append("; ");
                        cookies = new StringBuilder(cookies.substring(0, cookies.length() - 2));

                        SharedPreferencesUtil.putString(SharedPreferencesUtil.mid, getInfoFromCookie("DedeUserID", cookies.toString()));
                        SharedPreferencesUtil.putString(SharedPreferencesUtil.csrf, getInfoFromCookie("bili_jct", cookies.toString()));
                        SharedPreferencesUtil.putString(SharedPreferencesUtil.accessKey, UserLoginApi.getAccessKey(cookies.toString()));
                        SharedPreferencesUtil.putString(SharedPreferencesUtil.cookies, cookies.toString());
                        SharedPreferencesUtil.putBoolean(SharedPreferencesUtil.setup,true);

                        Log.e("accesskey",SharedPreferencesUtil.getString(SharedPreferencesUtil.accessKey,""));

                        Intent intent = new Intent();
                        intent.setClass(LoginActivity.this, SplashActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    timeoutCount ++;
                    if(timeoutCount > 600) {
                        runOnUiThread(() -> scanStat.setText("二维码超时，点击上方重置"));
                        qrImageView.setEnabled(true);
                        this.cancel();
                    }
                } catch (ConnectException | UnknownHostException e) {
                    runOnUiThread(() -> scanStat.setText("无法获取二维码信息，点击上方重试"));
                    qrImageView.setEnabled(true);
                    this.cancel();
                    runOnUiThread(()-> ErrorUtil.quickErr(ErrorUtil.err_net,LoginActivity.this));
                    e.printStackTrace();
                } catch (Exception e) {
                    runOnUiThread(()-> ErrorUtil.quickErr(ErrorUtil.err_other,LoginActivity.this));
                    e.printStackTrace();
                }
            }
        }, 500, 500);
    }

    private String getInfoFromCookie(String name, String cookie)
    {
        String[] cookies = cookie.split("; ");
        for(String i : cookies)
        {
            if(i.contains(name + "="))
                return i.substring(name.length() + 1);
        }
        return "";
    }
}