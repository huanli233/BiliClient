package com.RobinNotBad.BiliClient.util;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;

import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import cn.luern0313.lson.LsonUtil;
import cn.luern0313.lson.element.LsonObject;


//表情包工具，用于将文本中的表情包替换为对应图片，部分代码来自catGPT
//2023-07-23

public class EmoteUtil {

    public static SpannableString textReplaceEmote(String text, JSONObject emote, float scale, Context context) throws JSONException, ExecutionException, InterruptedException {
        SpannableString result = new SpannableString(text);
        if(emote!=null && emote.length()>0) {
            LsonObject lsonEmote = LsonUtil.parseAsObject(emote.toString());    //最终还是用了Lson的一个功能，因为原生方式确实难以解决，还好这个功能是github版已有的
            String[] emoteKeys = lsonEmote.getKeys();                           //你看这多简单，唉，但是仅用这一处却引用整个库确实有些浪费，如果我有时间就自己写了。就当是致敬了罢（
            for (int i = 0; i < emote.length(); i++) {    //遍历每一个表情包（B站在返回数据中给了此评论中出现的所有表情包）
                JSONObject key = emote.getJSONObject(emoteKeys[i]);
                String emoteUrl = key.getString("url");
                int size = key.getJSONObject("meta").getInt("size");  //B站十分贴心的帮你把表情包大小都写好了，快说谢谢蜀黍

                Drawable drawable = Glide.with(context).asDrawable().load(emoteUrl).submit().get();  //获得url并通过glide得到一张图片

                drawable.setBounds(0, 0, (int) (size * LittleToolsUtil.sp2px(18,context) * scale), (int) (size * LittleToolsUtil.sp2px(18,context) * scale));  //参考了隔壁腕上哔哩并进行了改进

                int start = text.indexOf(emoteKeys[i]);    //检测此字符串的起始位置
                while (start>=0) {
                    int end = start + emoteKeys[i].length();    //计算得出结束位置
                    ImageSpan imageSpan = new ImageSpan(drawable, ImageSpan.ALIGN_BOTTOM);  //获得一个imagespan  这句不能放while上面，imagespan不可以复用，我也不知道为什么
                    result.setSpan(imageSpan,start,end,SpannableStringBuilder.SPAN_INCLUSIVE_EXCLUSIVE);  //替换
                    start = text.indexOf(emoteKeys[i],end);    //重新检测起始位置，直到找不到，然后开启下一个循环
                }
            }
        }
        return result;
    }

}
