package com.RobinNotBad.BiliClient.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.video.VideoInfoActivity;
import com.RobinNotBad.BiliClient.listener.OnItemClickListener;
import com.RobinNotBad.BiliClient.model.UserInfo;
import com.RobinNotBad.BiliClient.model.VideoCard;
import com.RobinNotBad.BiliClient.util.LittleToolsUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

//用户信息页专用Adapter

public class UserInfoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    ArrayList<VideoCard> videoCard;
    UserInfo userInfo;
    OnItemClickListener mClickListener;

    public void setOnClickJumpListener(){
        setOnItemClickListener(position -> {
            if(position!=0) {
                Intent intent = new Intent();
                intent.setClass(context, VideoInfoActivity.class);
                intent.putExtra("bvid", videoCard.get(position - 1).getBvid());
                intent.putExtra("aid", videoCard.get(position - 1).getAid());
                context.startActivity(intent);
            }
        });
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        this.mClickListener = listener;
    }

    public UserInfoAdapter(Context context, ArrayList<VideoCard> videoCard, UserInfo userInfo) {
        this.context = context;
        this.videoCard = videoCard;
        this.userInfo = userInfo;
    }


    public void setVideoCards(ArrayList<VideoCard> videoCard) { this.videoCard = videoCard; }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(viewType != 0) {
            View view = LayoutInflater.from(this.context).inflate(R.layout.cell_video_list, parent, false);
            return new VideoCardHolder(view, mClickListener);
        }
        else {
            View view = LayoutInflater.from(this.context).inflate(R.layout.cell_user_info, parent, false);
            return new UserInfoHolder(view);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if(holder instanceof VideoCardHolder) {
            int realPosition = position - 1;
            VideoCardHolder videoCardHolder = (VideoCardHolder) holder;
            videoCardHolder.title.setText(videoCard.get(realPosition).getTitle());
            String upNameStr = videoCard.get(realPosition).getUpName();
            if (upNameStr.equals("")) {
                videoCardHolder.upName.setVisibility(View.GONE);
                videoCardHolder.upIcon.setVisibility(View.GONE);
            } else videoCardHolder.upName.setText(upNameStr);

            String playTimesStr = videoCard.get(realPosition).getView();
            if (playTimesStr.equals("")) {
                videoCardHolder.playIcon.setVisibility(View.GONE);
                videoCardHolder.playTimes.setVisibility(View.GONE);
            } else videoCardHolder.playTimes.setText(playTimesStr);

            Glide.with(this.context).load(videoCard.get(realPosition).getCover())
                    .apply(RequestOptions.bitmapTransform(new RoundedCorners(8)))
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(videoCardHolder.cover);
        }
        if (holder instanceof UserInfoHolder){
            UserInfoHolder userInfoHolder = (UserInfoHolder) holder;
            userInfoHolder.userName.setText(userInfo.getName());
            userInfoHolder.userDesc.setText(userInfo.getSign());
            userInfoHolder.userFans.setText(LittleToolsUtil.toWan(userInfo.getFollower()) + "粉丝");
            Glide.with(this.context).load(userInfo.getAvatar())
                    .placeholder(R.drawable.akari)
                    .apply(RequestOptions.circleCropTransform())
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(userInfoHolder.userAvatar);
        }
    }

    @Override
    public int getItemCount() {
        return videoCard.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        return (position==0 ? 0 : 1);
    }

    public static class VideoCardHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView title,upName,playTimes;
        ImageView cover,playIcon,upIcon;
        CardView cardView;
        OnItemClickListener mListener;

        public VideoCardHolder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);
            mListener = listener;
            title = itemView.findViewById(R.id.listVideoTitle);
            upName = itemView.findViewById(R.id.listUpName);
            playTimes = itemView.findViewById(R.id.listPlayTimes);
            cover = itemView.findViewById(R.id.listCover);
            cardView = itemView.findViewById(R.id.cardView);
            playIcon = itemView.findViewById(R.id.imageView3);
            upIcon = itemView.findViewById(R.id.avatarIcon);
            cardView.setOnClickListener(this);
        }
        @Override
        public void onClick(View v){
            mListener.onItemClick(getAdapterPosition());
        }
    }

    public static class UserInfoHolder extends RecyclerView.ViewHolder{
        TextView userName,userFans,userDesc;
        ImageView userAvatar;

        public UserInfoHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.userName);
            userDesc = itemView.findViewById(R.id.userDesc);
            userFans = itemView.findViewById(R.id.userFans);
            userAvatar = itemView.findViewById(R.id.userAvatar);
        }
    }
}
