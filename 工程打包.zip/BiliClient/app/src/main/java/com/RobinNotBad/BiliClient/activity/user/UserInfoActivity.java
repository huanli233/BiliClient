package com.RobinNotBad.BiliClient.activity.user;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.RobinNotBad.BiliClient.adapter.UserInfoAdapter;
import com.RobinNotBad.BiliClient.api.UserInfoApi;
import com.RobinNotBad.BiliClient.model.UserInfo;
import com.RobinNotBad.BiliClient.model.VideoCard;
import com.RobinNotBad.BiliClient.util.ErrorUtil;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

//用户信息页面
//2023-08-07

public class UserInfoActivity extends BaseActivity {

    private long mid;
    private boolean bottom = false;
    private int page = 1;
    private boolean refreshing = false;
    private ArrayList<VideoCard> videoList;
    private RecyclerView recyclerView;
    private UserInfoAdapter userInfoAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        findViewById(R.id.top).setOnClickListener(view -> finish());
        recyclerView = findViewById(R.id.recyclerView);

        Intent intent = getIntent();
        mid = intent.getLongExtra("mid",0);

        videoList = new ArrayList<>();

        new Thread(()->{
            try {
                UserInfo userInfo = UserInfoApi.getUserInfo(mid);
                bottom = (UserInfoApi.getUserVideos(mid,page,"",videoList) == 1);
                userInfoAdapter = new UserInfoAdapter(this,videoList,userInfo);
                userInfoAdapter.setOnClickJumpListener();
                runOnUiThread(()->{
                    recyclerView.setLayoutManager(new LinearLayoutManager(this));
                    recyclerView.setAdapter(userInfoAdapter);
                    recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                        @Override
                        public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                            super.onScrollStateChanged(recyclerView, newState);
                        }

                        @Override
                        public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                            super.onScrolled(recyclerView, dx, dy);
                            LinearLayoutManager manager = (LinearLayoutManager) recyclerView.getLayoutManager();
                            assert manager != null;
                            int lastItemPosition = manager.findLastCompletelyVisibleItemPosition();  //获取最后一个完全显示的itemPosition
                            int itemCount = manager.getItemCount();
                            if (lastItemPosition >= (itemCount - 3) && dy > 0 && !refreshing && !bottom) {// 滑动到倒数第三个就可以刷新了
                                refreshing = true;
                                new Thread(() -> continueLoading()).start(); //加载第二页
                            }
                        }
                    });
                });
            } catch (IOException e){
                runOnUiThread(()-> ErrorUtil.quickErr(ErrorUtil.err_net,this));
                e.printStackTrace();
            } catch (JSONException e) {
                runOnUiThread(()->ErrorUtil.quickErr(ErrorUtil.err_json,this));
                e.printStackTrace();
            }
        }).start();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void continueLoading() {
        page++;
        try {
            bottom = (UserInfoApi.getUserVideos(mid,page,"",videoList) == 1);
            runOnUiThread(()->{
                userInfoAdapter.setVideoCards(videoList);
                userInfoAdapter.notifyDataSetChanged();
            });
            if(bottom) Log.e("debug","到底啦");
            refreshing = false;
        } catch (IOException e){
            runOnUiThread(()-> ErrorUtil.quickErr(ErrorUtil.err_net,this));
            e.printStackTrace();
        } catch (JSONException e) {
            runOnUiThread(()->ErrorUtil.quickErr(ErrorUtil.err_json,this));
            e.printStackTrace();
        }
    }

}