package com.RobinNotBad.BiliClient.model;


import java.util.ArrayList;

public class VideoInfo {
    private final String bvid;
    private final long aid;
    private final String title;
    private final String upName;
    private final String cover;
    private final String description;
    private final String upIcon;
    private final long mid;
    private final int views;
    private int like;
    private int coin;
    private int reply;
    private final int danmaku;
    private int favorite;
    private final ArrayList<String> pagenames;
    private final ArrayList<Integer> cids;

    public String getTitle() {
        return title;
    }

    public String getUpName() {
        return upName;
    }

    public String getUpIcon() {
        return upIcon;
    }

    public String getCover() {
        return cover;
    }

    public String getDescription() {
        return description;
    }

    public long getMid() {
        return mid;
    }

    public int getViews() {
        return views;
    }

    public int getLike() {
        return like;
    }

    public void setLike(int like) {
        this.like = like;
    }

    public int getCoin() {
        return coin;
    }

    public void setCoin(int coin) {
        this.coin = coin;
    }

    public int getReply() {
        return reply;
    }

    public void setReply(int reply) {
        this.reply = reply;
    }

    public int getDanmaku() {
        return danmaku;
    }

    public void setFavorite(int favorite) {
        this.favorite = favorite;
    }

    public int getFavorite() {
        return favorite;
    }

    public ArrayList<String> getPagenames() {
        return pagenames;
    }

    public ArrayList<Integer> getCids() {
        return cids;
    }

    public String getBvid() {
        return bvid;
    }

    public long getAid() {
        return aid;
    }

    public VideoInfo(String bvid, long aid, String title, String upName, String cover, String description, String upIcon, long mid, int views, int like, int coin, int reply, int danmaku, int favorite, ArrayList<String> pagenames, ArrayList<Integer> cids) {
        this.bvid = bvid;
        this.aid = aid;
        this.title = title;
        this.upName = upName;
        this.cover = cover;
        this.description = description;
        this.upIcon = upIcon;
        this.mid = mid;
        this.views = views;
        this.like = like;
        this.coin = coin;
        this.reply = reply;
        this.danmaku = danmaku;
        this.favorite = favorite;
        this.pagenames = pagenames;
        this.cids = cids;
    }



}
