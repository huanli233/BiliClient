package com.RobinNotBad.BiliClient.model;


public class VideoCard {
    private final String title;
    private final String upName;
    private final String view;
    private final String cover;
    private final long aid;
    private final String bvid;

    public String getTitle() {
        return title;
    }

    public String getUpName() {
        return upName;
    }

    public String getView() {
        return view;
    }

    public String getCover() {
        return cover;
    }

    public long getAid() {
        return aid;
    }

    public String getBvid() {
        return bvid;
    }

    public VideoCard(String title, String upName, String view, String cover, long aid, String bvid) {
        this.title = title;
        this.upName = upName;
        this.view = view;
        this.cover = cover;
        this.aid = aid;
        this.bvid = bvid;
    }
}
