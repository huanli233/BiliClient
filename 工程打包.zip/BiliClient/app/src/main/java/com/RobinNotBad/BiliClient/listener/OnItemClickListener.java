package com.RobinNotBad.BiliClient.listener;

import android.view.View;

//自定义Listener
//搞不懂为啥RecyclerView没有自带这个

public interface OnItemClickListener {
    public void onItemClick(int position);

}
