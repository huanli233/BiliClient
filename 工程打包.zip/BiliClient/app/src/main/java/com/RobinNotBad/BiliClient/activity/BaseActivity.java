package com.RobinNotBad.BiliClient.activity;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;


public class BaseActivity extends AppCompatActivity {

    //调整应用内dpi的代码，所有Activity都要继承于BaseActivity才能调大小
    //我发现我似乎是第一个在手表应用上做这个功能的，相当实用但是可能想到的人不多
    @Override
    protected void attachBaseContext(Context newBase) {

        SharedPreferencesUtil.initSharedPrefs(newBase);

        float dpiTimes = SharedPreferencesUtil.getFloat("dpi", 1.0F);
        if(dpiTimes != 1.0F) {    //似乎有些低版本设备不支持，所以如果默认值就不要调整以免闪退
            Resources res = newBase.getResources();
            Configuration configuration = res.getConfiguration();
            WindowManager windowManager = (WindowManager) newBase.getSystemService(Context.WINDOW_SERVICE);
            Display display = windowManager.getDefaultDisplay();
            DisplayMetrics metrics = new DisplayMetrics();
            display.getRealMetrics(metrics);
            int dpi = metrics.densityDpi;
            Log.e("debug-系统dpi", String.valueOf(dpi));
            configuration.densityDpi = (int) (dpi * dpiTimes);
            Log.e("debug-应用dpi", String.valueOf((int) (dpi * dpiTimes)));
            Context confBase =  newBase.createConfigurationContext(configuration);

            super.attachBaseContext(confBase);
        }
        else super.attachBaseContext(newBase);
    }
}
