package com.RobinNotBad.BiliClient.model;

public class UserInfo {
    private final long mid;
    private final String name;
    private final String avatar;
    private final String sign;
    private final long follower;
    private final int level;
    private final boolean followed;

    public long getMid() {
        return mid;
    }

    public boolean isFollowed() {
        return followed;
    }

    public String getName() {
        return name;
    }

    public String getAvatar() {
        return avatar;
    }

    public String getSign() {
        return sign;
    }

    public long getFollower() {
        return follower;
    }

    public int getLevel() {
        return level;
    }

    public UserInfo(long mid, String name, String avatar, String sign, long follower, int level, boolean followed) {
        this.mid = mid;
        this.name = name;
        this.avatar = avatar;
        this.sign = sign;
        this.follower = follower;
        this.level = level;
        this.followed = followed;
    }
}
