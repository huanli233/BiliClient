package com.RobinNotBad.BiliClient.model;

import org.json.JSONObject;

import java.util.ArrayList;

public class VideoReply {
    private final long rpid;
    private final String pubTime;
    private final long senderID;
    private final String senderName;
    private final String senderAvatar;
    private final String message;
    private final JSONObject emote;
    private ArrayList<String> pictureList;
    private int likeCount;
    private final boolean upLiked;
    private boolean upReplied;
    private boolean liked;
    private int childCount;
    private ArrayList<String> childUNameList;
    private ArrayList<String> childMsgList;

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public boolean isLiked() {
        return liked;
    }

    public void setLiked(boolean liked) {
        this.liked = liked;
    }

    public JSONObject getEmote() {
        return emote;
    }

    public String getPubTime() {
        return pubTime;
    }

    public boolean isUpLiked() {
        return upLiked;
    }

    public boolean isUpReplied() {
        return upReplied;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public String getSenderAvatar() {
        return senderAvatar;
    }

    public long getRpid() {
        return rpid;
    }

    public long getSenderID() {
        return senderID;
    }

    public String getSenderName() {
        return senderName;
    }

    public String getMessage() {
        return message;
    }

    public ArrayList<String> getPictureList() {
        return pictureList;
    }

    public int getChildCount() {
        return childCount;
    }

    public ArrayList<String> getChildUNameList() {
        return childUNameList;
    }

    public ArrayList<String> getChildMsgList() {
        return childMsgList;
    }


    public VideoReply(long rpid, String pubTime, long senderID, String senderName, String senderAvatar, String message, JSONObject emote, ArrayList<String> pictureList, int likeCount, boolean upLiked, boolean upReplied,boolean liked, int childCount, ArrayList<String> childUNameList, ArrayList<String> childMsgList) {
        this.rpid = rpid;
        this.pubTime = pubTime;
        this.senderID = senderID;
        this.senderName = senderName;
        this.senderAvatar = senderAvatar;
        this.message = message;
        this.emote = emote;
        this.pictureList = pictureList;
        this.likeCount = likeCount;
        this.upLiked = upLiked;
        this.liked = liked;
        this.upReplied = upReplied;
        this.childCount = childCount;
        this.childUNameList = childUNameList;
        this.childMsgList = childMsgList;
    }

    public VideoReply(long rpid, String pubTime, long senderID, String senderName, String senderAvatar, String message, JSONObject emote, int likeCount, boolean upLiked, boolean liked) {
        this.rpid = rpid;
        this.pubTime = pubTime;
        this.senderID = senderID;
        this.senderName = senderName;
        this.senderAvatar = senderAvatar;
        this.message = message;
        this.emote = emote;
        this.likeCount = likeCount;
        this.upLiked = upLiked;
        this.liked = liked;
    }
}
