package com.RobinNotBad.BiliClient.api;

import android.util.Log;

import com.RobinNotBad.BiliClient.util.NetWorkUtil;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;

import java.io.IOException;

public class HistoryApi {
    public static void reportHistory(long aid, long cid,long mid, long progress) throws IOException {
        String url = "https://api.bilibili.com/x/report/web/heartbeat";
        String per = "aid=" + aid + "&cid=" + cid + "&mid=" + mid + "&csrf=" + SharedPreferencesUtil.getString("csrf","") + "&played_time=" + progress + "&realtime=0&start_ts=" + (System.currentTimeMillis() / 1000) + "&type=3&dt=2&play_type=1";
        Log.e("历史记录上报",url + "?" + per);
        NetWorkUtil.post(url,per,ConfInfoApi.defHeaders);
    }
}
