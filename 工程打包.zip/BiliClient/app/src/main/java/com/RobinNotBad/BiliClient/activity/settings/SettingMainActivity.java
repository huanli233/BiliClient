package com.RobinNotBad.BiliClient.activity.settings;


import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.google.android.material.card.MaterialCardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.MenuActivity;

public class SettingMainActivity extends BaseActivity {

    public static SettingMainActivity instance = null;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_main);
        Log.e("debug","进入设置页");
        instance = this;    //给菜单页面调用，用来结束本页面

        findViewById(R.id.top).setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(SettingMainActivity.this,MenuActivity.class);
            intent.putExtra("from",3);
            startActivity(intent);
        });

        MaterialCardView uiSetting = findViewById(R.id.uiSetting);
        uiSetting.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(SettingMainActivity.this, UISettingActivity.class);
            startActivity(intent);
        });

        MaterialCardView openSource = findViewById(R.id.openSource);
        openSource.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(SettingMainActivity.this, OpenSourceActivity.class);
            startActivity(intent);
        });

        MaterialCardView about = findViewById(R.id.about);
        about.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(SettingMainActivity.this, AboutActivity.class);
            startActivity(intent);
        });
    }
}