package com.RobinNotBad.BiliClient.activity.video;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.adapter.ReplyAdapter;
import com.RobinNotBad.BiliClient.api.ReplyApi;
import com.RobinNotBad.BiliClient.model.VideoReply;
import com.RobinNotBad.BiliClient.util.ErrorUtil;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

//视频下评论页面，评论详情见ReplyInfoActivity
//部分通用代码在VideoReplyAdapter内
//2023-07-22

public class VideoReplyFragment extends Fragment {

    private long aid;
    private RecyclerView recyclerView;
    private ArrayList<VideoReply> replyList;
    private ReplyAdapter replyAdapter;
    private boolean refreshing = false;
    private boolean bottom = false;
    private int page = 1;

    public VideoReplyFragment() {

    }

    public static VideoReplyFragment newInstance(long aid) {
        VideoReplyFragment fragment = new VideoReplyFragment();
        Bundle args = new Bundle();
        args.putLong("aid", aid);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            aid = getArguments().getLong("aid");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_video_reply, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recyclerView);

        Log.e("debug-av号",String.valueOf(aid));

        replyList = new ArrayList<>();

        new Thread(()->{
            try {
                int result = ReplyApi.getReplies(aid,0,page,replyList);
                if(result != -1) {
                    replyAdapter = new ReplyAdapter(getContext(), replyList,aid);
                    requireActivity().runOnUiThread(()->{
                        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                        recyclerView.setAdapter(replyAdapter);
                        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                            @Override
                            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                                super.onScrollStateChanged(recyclerView, newState);
                            }

                            @Override
                            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                                super.onScrolled(recyclerView, dx, dy);
                                LinearLayoutManager manager = (LinearLayoutManager) recyclerView.getLayoutManager();
                                assert manager != null;
                                int lastItemPosition = manager.findLastCompletelyVisibleItemPosition();  //获取最后一个完全显示的itemPosition
                                int itemCount = manager.getItemCount();
                                if (lastItemPosition >= (itemCount - 3) && dy > 0 && !refreshing && !bottom) {// 滑动到倒数第三个就可以刷新了
                                    refreshing = true;
                                    new Thread(() -> continueLoading()).start(); //加载第二页
                                }
                            }
                        });
                    });
                    if(result == 1) {
                        Log.e("debug","到底了");
                        bottom = true;
                    }
                }

            } catch (IOException e){
                requireActivity().runOnUiThread(()-> ErrorUtil.quickErr(ErrorUtil.err_net,getContext()));
                e.printStackTrace();
            } catch (JSONException e) {
                requireActivity().runOnUiThread(()->ErrorUtil.quickErr(ErrorUtil.err_json,getContext()));
                e.printStackTrace();
            }
        }).start();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void continueLoading() {
        page++;
        try {
            int result = ReplyApi.getReplies(aid,0,page, replyList);
            if(result != -1){
                Log.e("debug","下一页");
                requireActivity().runOnUiThread(()->{
                    replyAdapter.setReplies(replyList);
                    replyAdapter.notifyDataSetChanged();
                });
                if(result == 1) {
                    Log.e("debug","到底了");
                    bottom = true;
                }
            }
            refreshing = false;
        } catch (IOException e){
            requireActivity().runOnUiThread(()-> ErrorUtil.quickErr(ErrorUtil.err_net,getContext()));
            e.printStackTrace();
        } catch (JSONException e) {
            requireActivity().runOnUiThread(()->ErrorUtil.quickErr(ErrorUtil.err_json,getContext()));
            e.printStackTrace();
        }
    }
}