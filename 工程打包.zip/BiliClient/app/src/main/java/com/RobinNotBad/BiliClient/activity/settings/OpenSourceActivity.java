package com.RobinNotBad.BiliClient.activity.settings;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;

public class OpenSourceActivity extends BaseActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opensource);

        findViewById(R.id.top).setOnClickListener(view -> finish());
    }
}