package com.RobinNotBad.BiliClient.activity.user;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.RobinNotBad.BiliClient.activity.MenuActivity;
import com.RobinNotBad.BiliClient.api.UserInfoApi;
import com.RobinNotBad.BiliClient.model.UserInfo;
import com.RobinNotBad.BiliClient.util.LittleToolsUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.card.MaterialCardView;

import org.json.JSONException;

import java.io.IOException;

public class MySpaceActivity extends BaseActivity {

    @SuppressLint("StaticFieldLeak")
    public static MySpaceActivity instance = null;
    private ImageView userAvatar;
    private TextView userName, userFans, userDesc;
    private MaterialCardView myInfo,follow,watchLater,favorite;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myspace);
        instance = this;
        Log.e("debug","进入个人页");

        findViewById(R.id.top).setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(MySpaceActivity.this, MenuActivity.class);
            intent.putExtra("from",2);
            startActivity(intent);
        });
        userAvatar = findViewById(R.id.userAvatar);
        userName = findViewById(R.id.userName);
        userFans = findViewById(R.id.userFans);
        userDesc = findViewById(R.id.userDesc);

        myInfo = findViewById(R.id.myinfo);
        follow = findViewById(R.id.follow);
        watchLater = findViewById(R.id.watchlater);
        favorite = findViewById(R.id.favorite);



        new Thread(()->{
            try {
                UserInfo userInfo = UserInfoApi.getCurrentUserInfo();
                runOnUiThread(() -> {
                    Glide.with(MySpaceActivity.this).load(userInfo.getAvatar())
                            .placeholder(R.drawable.akari).apply(RequestOptions.circleCropTransform())
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .into(userAvatar);
                    userName.setText(userInfo.getName());
                    userFans.setText(LittleToolsUtil.toWan(userInfo.getFollower()) + "粉丝");
                    userDesc.setText(userInfo.getSign());

                    myInfo.setOnClickListener(view -> {
                        Intent intent = new Intent();
                        intent.setClass(MySpaceActivity.this, UserInfoActivity.class);
                        intent.putExtra("mid",userInfo.getMid());
                        startActivity(intent);
                    });

                    favorite.setOnClickListener(view -> {
                        Intent intent = new Intent();
                        intent.setClass(MySpaceActivity.this, FavoriteActivity.class);
                        intent.putExtra("mid",userInfo.getMid());
                        startActivity(intent);
                    });
                });
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }).start();


    }
}