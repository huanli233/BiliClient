package com.RobinNotBad.BiliClient.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.adapter.ViewPagerImageAdapter;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.target.Target;
import com.github.chrisbanes.photoview.PhotoView;

import java.util.ArrayList;
import java.util.List;

public class ImageViewerActivity extends AppCompatActivity {

    //简简单单的图片查看页面
    //2023-07-21

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_viewer);
        Intent intent = getIntent();
        ArrayList<String> imageList = intent.getStringArrayListExtra("imageList");

        ViewPager viewPager = findViewById(R.id.viewPager);
        findViewById(R.id.top).setOnClickListener(view -> finish());

        List<PhotoView> photoViewList = new ArrayList<>();

        for (int i = 0; i < imageList.size(); i++) {
            PhotoView photoView = new PhotoView(this);
            Glide.with(this).load(imageList.get(i))
                    .override(Target.SIZE_ORIGINAL)//override这一项一定要加，这样才会显示原图，不然一放大就糊成使
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(photoView);
            photoViewList.add(photoView);
        }

        ViewPagerImageAdapter vpiAdapter = new ViewPagerImageAdapter(photoViewList);

        viewPager.setAdapter(vpiAdapter);
    }
}