package com.RobinNotBad.BiliClient.activity.video;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.user.UserInfoActivity;
import com.RobinNotBad.BiliClient.api.HistoryApi;
import com.RobinNotBad.BiliClient.api.VideoInfoApi;
import com.RobinNotBad.BiliClient.model.VideoInfo;
import com.RobinNotBad.BiliClient.util.ErrorUtil;
import com.RobinNotBad.BiliClient.util.LittleToolsUtil;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.card.MaterialCardView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Locale;

//真正的视频详情页
//2023-07-17

public class VideoInfoFragment extends Fragment {

    private VideoInfo videoInfo;
    private JSONObject data;
    private String bvid;
    private long aid;

    private ImageView cover,upIcon;
    private TextView title,description,upName,views,bvidText,danmakuCount;


    public VideoInfoFragment() {

    }


    public static VideoInfoFragment newInstance(String bvid,long aid) {
        VideoInfoFragment fragment = new VideoInfoFragment();
        Bundle args = new Bundle();
        args.putString("bvid", bvid);
        args.putLong("aid",aid);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            bvid = getArguments().getString("bvid");
            aid = getArguments().getLong("aid");
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_video_info, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState){
        super.onViewCreated(view,savedInstanceState);

        cover = view.findViewById(R.id.cover);
        upIcon = view.findViewById(R.id.upInfo_Icon);
        title = view.findViewById(R.id.title);
        description = view.findViewById(R.id.description);
        upName = view.findViewById(R.id.upInfo_Name);
        views = view.findViewById(R.id.viewsCount);
        Button play = view.findViewById(R.id.play);
        MaterialCardView upCard = view.findViewById(R.id.upInfo);
        bvidText = view.findViewById(R.id.bvidText);
        danmakuCount = view.findViewById(R.id.danmakuCount);



        new Thread(()->{
            try {
                if(bvid.equals("")) data = VideoInfoApi.getJsonByAid(aid);
                else data = VideoInfoApi.getJsonByBvid(bvid);

                videoInfo = VideoInfoApi.getInfoByJson(data);

                HistoryApi.reportHistory(aid,videoInfo.getCids().get(0), videoInfo.getMid(), 0);

                requireActivity().runOnUiThread(()->{
                    Glide.with(view.getContext()).load(videoInfo.getCover()).placeholder(R.drawable.placeholder)
                            .apply(RequestOptions.bitmapTransform(new RoundedCorners(LittleToolsUtil.dp2px(6,view.getContext()))))
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .into(cover);
                    Glide.with(view.getContext()).load(videoInfo.getUpIcon()).placeholder(R.drawable.akari)
                            .apply(RequestOptions.circleCropTransform())
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .into(upIcon);
                    upName.setText(videoInfo.getUpName());

                    int viewsInt = videoInfo.getViews();
                    String viewsStr;
                    if(viewsInt>=10000) viewsStr = String.format(Locale.CHINA, "%.1f", (float)viewsInt/10000) + "万观看";
                    else viewsStr = viewsInt + "观看";
                    views.setText(viewsStr);

                    danmakuCount.setText(String.valueOf(videoInfo.getDanmaku()));
                    bvidText.setText(videoInfo.getBvid());
                    description.setText(videoInfo.getDescription());
                    title.setText(videoInfo.getTitle());

                    play.setOnClickListener(view1 -> {
                        Glide.get(requireContext()).clearMemory();
                        //在播放前清除内存缓存，因为手表内存太小了，播放完回来经常把Activity全释放掉
                        //...经过测试，tmd还是会释放

                        if(videoInfo.getPagenames().size()>1){
                            Intent intent = new Intent();
                            intent.setClass(view.getContext(), MultiPageActivity.class);
                            intent.putExtra("bvid",videoInfo.getBvid());
                            intent.putExtra("aid",videoInfo.getAid());
                            intent.putExtra("mid",videoInfo.getMid());
                            intent.putExtra("cids", videoInfo.getCids());
                            intent.putExtra("pages", videoInfo.getPagenames());
                            startActivity(intent);
                        }
                        else{
                            new Thread(()->{
                                Intent intent = new Intent();
                                intent.setClassName("com.xinxiangshicheng.wearbiliplayer.cn", "com.xinxiangshicheng.wearbiliplayer.cn.ReceiveActivity");
                                intent.setAction(Intent.ACTION_VIEW);
                                Log.e("cookie",SharedPreferencesUtil.getString("cookies",""));
                                intent.putExtra("cookie", SharedPreferencesUtil.getString("cookies",""));
                                intent.setData(Uri.parse("wearbiliplayer://receive:8080/play?&bvid=" + videoInfo.getBvid() + "&cid=" + videoInfo.getCids().get(0) + "&aid=" + videoInfo.getAid()));
                                startActivity(intent);    //其实aid和bvid有一个就可以了，为了保险两个都传
                            }).start();
                        }
                    });

                    upCard.setOnClickListener(view1 ->{
                        Intent intent = new Intent();
                        intent.setClass(view.getContext(), UserInfoActivity.class);
                        intent.putExtra("mid",videoInfo.getMid());
                        startActivity(intent);
                    });
                });
            } catch (IOException e) {
                requireActivity().runOnUiThread(() -> ErrorUtil.quickErr(ErrorUtil.err_net,view.getContext()));
                e.printStackTrace();
            } catch (JSONException e) {
                requireActivity().runOnUiThread(() -> ErrorUtil.quickErr(ErrorUtil.err_json,view.getContext()));
                e.printStackTrace();
            }
        }).start();
    }
}