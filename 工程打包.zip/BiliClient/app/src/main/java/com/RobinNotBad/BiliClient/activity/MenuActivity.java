package com.RobinNotBad.BiliClient.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.user.MySpaceActivity;
import com.RobinNotBad.BiliClient.activity.video.RecommendActivity;
import com.RobinNotBad.BiliClient.activity.video.SearchActivity;
import com.RobinNotBad.BiliClient.activity.settings.SettingMainActivity;

//菜单页面
//2023-07-14

public class MenuActivity extends BaseActivity {

    private int from;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Log.e("debug","进入菜单页");

        Intent intent = getIntent();
        from = intent.getIntExtra("from",0);

        findViewById(R.id.top).setOnClickListener(view -> finish());

        Button main = findViewById(R.id.main);
        Button search = findViewById(R.id.search);
        Button profile = findViewById(R.id.profile);
        Button settings = findViewById(R.id.settings);

        main.setOnClickListener(view -> {
            if(from==0) finish();
            else killAndJump(RecommendActivity.class);
        });

        search.setOnClickListener(view -> {
            if(from==1) finish();
            else killAndJump(SearchActivity.class);
        });

        profile.setOnClickListener(view -> {
            if(from==2) finish();
            else killAndJump(MySpaceActivity.class);
        });

        settings.setOnClickListener(view -> {
            if(from==3) finish();
            else killAndJump(SettingMainActivity.class);
        });
    }

    private void killAndJump(Class<?> jump){
        Intent intent = new Intent();
        intent.setClass(MenuActivity.this,jump);
        startActivity(intent);
        switch (from){
            case 0:
                RecommendActivity.instance.finish();
                break;
            case 1:
                SearchActivity.instance.finish();
                break;
            case 2:
                MySpaceActivity.instance.finish();
                break;
            case 3:
                SettingMainActivity.instance.finish();
                break;
        }
        finish();
    }
}