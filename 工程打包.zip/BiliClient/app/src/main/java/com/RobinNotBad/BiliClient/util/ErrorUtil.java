package com.RobinNotBad.BiliClient.util;

import android.content.Context;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;

public class ErrorUtil {
    public static int err_other = 0;
    public static int err_net = 1;
    public static int err_json = 2;
    public static int err_player = 3;
    private static final String[] texts = {"其它错误(＃°Д°)","网络错误(＃°Д°)","数据解析错误(＃°Д°)","你没有安装小电视播放器awa"};

    public static void toastErr(String err, Context context){
        Toast.makeText(context, err, Toast.LENGTH_LONG).show();
    }
    public static void quickErr(int err,Context context){
        toastErr(texts[err],context);
    }
}
