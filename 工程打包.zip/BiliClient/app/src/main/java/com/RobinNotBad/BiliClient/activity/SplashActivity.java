package com.RobinNotBad.BiliClient.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.IOException;
import java.util.Objects;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.user.LoginActivity;
import com.RobinNotBad.BiliClient.activity.video.RecommendActivity;
import com.RobinNotBad.BiliClient.util.FileUtil;
import com.RobinNotBad.BiliClient.util.ErrorUtil;
import com.RobinNotBad.BiliClient.util.NetWorkUtil;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;

//启动页面

@SuppressLint("CustomSplashScreen")
public class SplashActivity extends BaseActivity {

    private TextView splashText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Log.e("debug","进入应用");

        splashText = findViewById(R.id.splashText);

        new Thread(()->{
            FileUtil.clearCache(this);  //先清个缓存（为了防止占用过大）
            if(SharedPreferencesUtil.getBoolean(SharedPreferencesUtil.setup,false)) {//判断是否登录
                try {
                    if(Objects.requireNonNull(NetWorkUtil.get("https://www.bilibili.com")).isSuccessful()){
                        Log.e("accesskey",SharedPreferencesUtil.getString(SharedPreferencesUtil.accessKey,""));
                        Thread.sleep(200);
                        Intent intent = new Intent();
                        intent.setClass(SplashActivity.this, RecommendActivity.class);   //已登录且联网，去首页
                        startActivity(intent);
                        finish();
                    }
                } catch (IOException | InterruptedException e) {
                    runOnUiThread(()-> {
                        ErrorUtil.quickErr(ErrorUtil.err_net,this);
                        splashText.setText("网络错误");
                    });
                    e.printStackTrace();
                }
            }
            else {
                Intent intent = new Intent();
                intent.setClass(SplashActivity.this, LoginActivity.class);   //没登录，去登录页面
                startActivity(intent);
                finish();
            }
        }).start();
    }
}