package com.RobinNotBad.BiliClient.activity.settings;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;

public class UISettingActivity extends BaseActivity {

    private EditText input;
    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_ui);
        Log.e("debug","进入界面设置");

        findViewById(R.id.top).setOnClickListener(view -> finish());

        input = findViewById(R.id.input);
        input.setText(String.valueOf(SharedPreferencesUtil.getFloat("dpi",1.0F)));
    }

    @SuppressLint("SuspiciousIndentation")
    @Override
    protected void onDestroy() {
        float dpiTimes = Float.parseFloat(input.getText().toString());
        if(dpiTimes >= 0.1F && dpiTimes <= 10.0F)
        SharedPreferencesUtil.putFloat("dpi",dpiTimes);
        Log.e("dpi",input.getText().toString());
        super.onDestroy();
    }
}