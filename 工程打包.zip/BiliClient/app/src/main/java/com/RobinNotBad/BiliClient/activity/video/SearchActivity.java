package com.RobinNotBad.BiliClient.activity.video;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.Toast;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.RobinNotBad.BiliClient.activity.MenuActivity;

import com.RobinNotBad.BiliClient.adapter.VideoCardAdapter;
import com.RobinNotBad.BiliClient.api.SearchApi;
import com.RobinNotBad.BiliClient.model.VideoCard;
import com.RobinNotBad.BiliClient.util.ErrorUtil;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

public class SearchActivity extends BaseActivity {

    private EditText keywordInput;
    private RecyclerView recyclerView;
    private ArrayList<VideoCard> videoCardList;
    private VideoCardAdapter videoCardAdapter;
    private String keyword;
    private boolean firstRefresh = true;
    private boolean refreshing = false;
    private boolean bottom = false;
    private int page = 0;

    @SuppressLint("StaticFieldLeak")
    public static SearchActivity instance = null;
    @SuppressLint({"MissingInflatedId", "NotifyDataSetChanged"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        instance = this;
        Log.e("debug","进入搜索页");

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
        videoCardList = new ArrayList<>();
        videoCardAdapter = new VideoCardAdapter(this,videoCardList);

        findViewById(R.id.top).setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(SearchActivity.this, MenuActivity.class);
            intent.putExtra("from",1);
            startActivity(intent);
        });

        View searchBtn = findViewById(R.id.search);
        searchBtn.setOnClickListener(view -> searchKeyword());
        keywordInput = findViewById(R.id.keywordInput);
        keywordInput.setOnEditorActionListener((textView, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE || event != null && KeyEvent.KEYCODE_ENTER == event.getKeyCode() && KeyEvent.ACTION_DOWN == event.getAction()) {
                searchKeyword();
            }
            return false;
        });


        videoCardAdapter.setOnClickJumpListener();

        recyclerView.setAdapter(videoCardAdapter);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                LinearLayoutManager manager = (LinearLayoutManager) recyclerView.getLayoutManager();
                assert manager != null;
                int lastItemPosition = manager.findLastCompletelyVisibleItemPosition();  //获取最后一个完全显示的itemPosition
                int itemCount = manager.getItemCount();
                if (lastItemPosition >= (itemCount - 3) && dy>0 && !refreshing && !bottom) {// 滑动到倒数第三个就可以刷新了
                    refreshing = true;
                    new Thread(() -> continueLoading()).start(); //加载第二页
                }
            }
        });



    }

    @SuppressLint("NotifyDataSetChanged")
    private void searchKeyword(){
        refreshing = true;
        bottom = false;
        if(keywordInput.getText().toString().equals("")){
            Toast.makeText(this, "你还木有输入内容哦(´･ω･`)?", Toast.LENGTH_SHORT).show();
        }
        else {
            keyword = keywordInput.getText().toString();
            new Thread(() -> {
                try {
                    videoCardList = new ArrayList<>();
                    videoCardAdapter.clearVideoCards();
                    if (firstRefresh) {
                        runOnUiThread(() -> recyclerView.setAdapter(videoCardAdapter));
                        firstRefresh = false;
                    } else runOnUiThread(() -> videoCardAdapter.notifyDataSetChanged());
                    page = 1;
                    JSONArray result = SearchApi.search(keyword, 1);
                    if(result!=null) {
                        SearchApi.getVideosFromSearchResult(result, videoCardList);
                        runOnUiThread(() -> {
                            videoCardAdapter.setVideoCards(videoCardList);
                            videoCardAdapter.notifyDataSetChanged();
                            Log.e("debug", "刷新");
                        });
                    }
                    else ErrorUtil.toastErr("搜索结果为空OwO",this);
                } catch (IOException e) {
                    runOnUiThread(() -> ErrorUtil.quickErr(ErrorUtil.err_net, this));
                    e.printStackTrace();
                } catch (JSONException e) {
                    runOnUiThread(() -> ErrorUtil.quickErr(ErrorUtil.err_json, this));
                    e.printStackTrace();
                }
                refreshing = false;
            }).start();
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private void continueLoading(){
        refreshing = true;
        page++;
        Log.e("debug","加载下一页");
        try {
            JSONArray result =  SearchApi.search(keyword,page);
            if(result!=null) {
                SearchApi.getVideosFromSearchResult(result, videoCardList);
                runOnUiThread(() -> {
                    videoCardAdapter.setVideoCards(videoCardList);
                    videoCardAdapter.notifyDataSetChanged();
                });
            }
            else {
                bottom = true;
                ErrorUtil.toastErr("已经到底啦OwO",this);
            }
        } catch (IOException e){
            runOnUiThread(()->ErrorUtil.quickErr(ErrorUtil.err_net,this));
            e.printStackTrace();
        } catch (JSONException e) {
            runOnUiThread(()->ErrorUtil.quickErr(ErrorUtil.err_json,this));
            e.printStackTrace();
        }
        refreshing = false;
    }

}