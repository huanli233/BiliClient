package com.RobinNotBad.BiliClient.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.video.VideoInfoActivity;
import com.RobinNotBad.BiliClient.listener.OnItemClickListener;
import com.RobinNotBad.BiliClient.model.VideoCard;
import com.RobinNotBad.BiliClient.util.LittleToolsUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

//视频卡片Adapter 适用于各种场景（迫真
//日期不记得了

public class VideoCardAdapter extends RecyclerView.Adapter<VideoCardAdapter.VideoCardHolder> {

    Context context;
    ArrayList<VideoCard> videoCard;
    OnItemClickListener mClickListener;

    public void setOnClickJumpListener(){
        setOnItemClickListener(position -> {
            Intent intent = new Intent();
            intent.setClass(context, VideoInfoActivity.class);
            intent.putExtra("bvid",videoCard.get(position).getBvid());
            intent.putExtra("aid",videoCard.get(position).getAid());
            context.startActivity(intent);
        });
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        this.mClickListener = listener;
    }

    public VideoCardAdapter(Context context, ArrayList<VideoCard> videoCard) {
        this.context = context;
        this.videoCard = videoCard;
    }


    public void setVideoCards(ArrayList<VideoCard> videoCard) { this.videoCard = videoCard; }

    public void clearVideoCards(){
        this.videoCard.clear();
    }

    @NonNull
    @Override
    public VideoCardAdapter.VideoCardHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(this.context).inflate(R.layout.cell_video_list,parent,false);
        return new VideoCardHolder(view,mClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoCardAdapter.VideoCardHolder holder, int position) {
        holder.title.setText(Html.fromHtml(videoCard.get(position).getTitle()));
        String upNameStr = videoCard.get(position).getUpName();
        if(upNameStr.equals("")){
            holder.upName.setVisibility(View.GONE);
            holder.upIcon.setVisibility(View.GONE);
        }
        else holder.upName.setText(upNameStr);

        String playTimesStr = videoCard.get(position).getView();
        if(playTimesStr.equals("")){
            holder.playIcon.setVisibility(View.GONE);
            holder.playTimes.setVisibility(View.GONE);
        }
        else holder.playTimes.setText(playTimesStr);

        Glide.with(this.context).load(videoCard.get(position).getCover())
                .apply(RequestOptions.bitmapTransform(new RoundedCorners(LittleToolsUtil.dp2px(5,context))))
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(holder.cover);
    }

    @Override
    public int getItemCount() {
        return videoCard.size();
    }

    public static class VideoCardHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView title,upName,playTimes;
        ImageView cover,playIcon,upIcon;
        CardView cardView;
        OnItemClickListener mListener;

        public VideoCardHolder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);
            mListener = listener;
            title = itemView.findViewById(R.id.listVideoTitle);
            upName = itemView.findViewById(R.id.listUpName);
            playTimes = itemView.findViewById(R.id.listPlayTimes);
            cover = itemView.findViewById(R.id.listCover);
            cardView = itemView.findViewById(R.id.cardView);
            playIcon = itemView.findViewById(R.id.imageView3);
            upIcon = itemView.findViewById(R.id.avatarIcon);
            cardView.setOnClickListener(this);
        }
        @Override
        public void onClick(View v){
            if(mListener!=null) mListener.onItemClick(getAdapterPosition());
        }
    }
}
