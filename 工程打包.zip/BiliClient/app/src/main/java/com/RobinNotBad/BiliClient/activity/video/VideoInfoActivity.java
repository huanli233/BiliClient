package com.RobinNotBad.BiliClient.activity.video;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.BaseActivity;
import com.RobinNotBad.BiliClient.adapter.ViewPagerFragmentAdapter;

import java.util.ArrayList;
import java.util.List;

//视频详情页，但这只是个壳，瓤是VideoInfoFragment和VideoReplyFragment

public class VideoInfoActivity extends BaseActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_info);
        Intent intent = getIntent();
        String bvid = intent.getStringExtra("bvid");
        long aid = intent.getLongExtra("aid",114514);

        findViewById(R.id.top).setOnClickListener(view -> finish());

        ViewPager viewPager = findViewById(R.id.viewPager);

        List<Fragment> fragmentList = new ArrayList<>();
        VideoInfoFragment viFragment = VideoInfoFragment.newInstance(bvid,aid);
        fragmentList.add(viFragment);
        VideoReplyFragment vpFragment = VideoReplyFragment.newInstance(aid);
        fragmentList.add(vpFragment);

        ViewPagerFragmentAdapter vpfAdapter = new ViewPagerFragmentAdapter(getSupportFragmentManager(), fragmentList);

        viewPager.setAdapter(vpfAdapter);  //没啥好说的，教科书式的ViewPager使用方法
    }
}