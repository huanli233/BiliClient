package com.RobinNotBad.BiliClient.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.ImageViewerActivity;
import com.RobinNotBad.BiliClient.activity.user.UserInfoActivity;
import com.RobinNotBad.BiliClient.activity.video.ReplyInfoActivity;
import com.RobinNotBad.BiliClient.model.VideoReply;
import com.RobinNotBad.BiliClient.util.EmoteUtil;
import com.RobinNotBad.BiliClient.util.ErrorUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.card.MaterialCardView;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

//评论Adapter
//2023-07-22

public class ReplyAdapter extends RecyclerView.Adapter<ReplyAdapter.ReplyHolder> {

    Context context;
    ArrayList<VideoReply> videoReply;
    long oid;

    public ReplyAdapter(Context context, ArrayList<VideoReply> videoReply, long oid) {
        this.context = context;
        this.videoReply = videoReply;
        this.oid = oid;
    }

    public void setReplies(ArrayList<VideoReply> videoReply) {
        this.videoReply = videoReply;
    }

    @NonNull
    @Override
    public ReplyAdapter.ReplyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(this.context).inflate(R.layout.cell_reply_list,parent,false);
        return new ReplyHolder(view);
    }

    @SuppressLint({"SetTextI18n", "SimpleDateFormat"})
    @Override
    public void onBindViewHolder(@NonNull ReplyAdapter.ReplyHolder holder, int position) {
        Glide.with(context).load(videoReply.get(position).getSenderAvatar())
                .placeholder(R.drawable.akari)
                .apply(RequestOptions.circleCropTransform())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(holder.replyAvatar);
        holder.userName.setText(videoReply.get(position).getSenderName());
        String text = videoReply.get(position).getMessage();
        holder.message.setText(text);  //防止加载速度慢时露出鸡脚
        new Thread(()->{
            try {
                SpannableString spannableString = EmoteUtil.textReplaceEmote(text, videoReply.get(position).getEmote(), 1.0f, context);
                ((Activity)context).runOnUiThread(()->holder.message.setText(spannableString));
            } catch (JSONException e) {
                ErrorUtil.quickErr(ErrorUtil.err_json,context);
                e.printStackTrace();
            } catch (ExecutionException e) {
                ErrorUtil.quickErr(ErrorUtil.err_other,context);
                e.printStackTrace();
            } catch (InterruptedException e) {
                ErrorUtil.quickErr(ErrorUtil.err_other,context);
                e.printStackTrace();
            }
        }).start();
        holder.likeCount.setText(String.valueOf(videoReply.get(position).getLikeCount()));
        if(videoReply.get(position).getChildCount() != 0) {           //这里，还有下面，一定要加else！
            holder.childReplyCard.setVisibility(View.VISIBLE);        //不然可能会导致错乱
            if(videoReply.get(position).isUpReplied()) holder.childCount.setText("UP主在内 共" + videoReply.get(position).getChildCount() + "条回复");
            else holder.childCount.setText("共" + videoReply.get(position).getChildCount() + "条回复");
        }
        else holder.childReplyCard.setVisibility(View.GONE);

        if(videoReply.get(position).isUpLiked()) holder.upLiked.setVisibility(View.VISIBLE);
        else holder.upLiked.setVisibility(View.GONE);
        holder.pubDate.setText(videoReply.get(position).getPubTime());

        if(videoReply.get(position).getPictureList() != null && videoReply.get(position).getPictureList().size()>0) {  //图片显示相关
            holder.imageCard.setVisibility(View.VISIBLE);
            Glide.with(context).load(videoReply.get(position).getPictureList().get(0))
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(holder.imageView);
            holder.imageCount.setText("共" + videoReply.get(position).getPictureList().size() + "张图片");
            holder.imageCard.setOnClickListener(view -> {
                Intent intent = new Intent();
                intent.setClass(context, ImageViewerActivity.class);
                intent.putExtra("imageList",videoReply.get(position).getPictureList());
                context.startActivity(intent);
            });
        }
        else holder.imageCard.setVisibility(View.GONE);

        holder.childReplyCard.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(context, ReplyInfoActivity.class);
            intent.putExtra("rpid",videoReply.get(position).getRpid());
            intent.putExtra("oid",oid);
            context.startActivity(intent);
        });

        holder.replyAvatar.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(context, UserInfoActivity.class);
            intent.putExtra("mid",videoReply.get(position).getSenderID());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return videoReply.size();
    }

    public static class ReplyHolder extends RecyclerView.ViewHolder{
        ImageView replyAvatar,likeBtn,dislikeBtn;
        ListView childReplies;
        TextView message,userName,pubDate,childCount,likeCount,replyBtn,upLiked,imageCount;
        LinearLayout childReplyCard;
        MaterialCardView imageCard;
        ImageView imageView;


        public ReplyHolder(@NonNull View itemView) {
            super(itemView);

            replyAvatar = itemView.findViewById(R.id.replyAvatar);
            likeBtn = itemView.findViewById(R.id.likeBtn);
            dislikeBtn = itemView.findViewById(R.id.dislikeBtn);
            childReplies = itemView.findViewById(R.id.repliesList);
            message = itemView.findViewById(R.id.replyText);
            userName = itemView.findViewById(R.id.replyUsername);
            pubDate = itemView.findViewById(R.id.replyPubDate);
            childCount = itemView.findViewById(R.id.repliesControl);
            likeCount = itemView.findViewById(R.id.likes);
            replyBtn = itemView.findViewById(R.id.replyBtn);
            upLiked = itemView.findViewById(R.id.upLiked);
            childReplyCard = itemView.findViewById(R.id.repliesCard);
            imageCard = itemView.findViewById(R.id.imageCard);
            imageCount = itemView.findViewById(R.id.imageCount);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
